// PTENit Production Firebase Configuration & Initialization
// Compatible with browser standalone & cPanel deployment

export const firebaseConfig = {
  projectId: "gen-lang-client-0227104370",
  appId: "1:607667886478:web:0b8a4c2f19454bac35acdf",
  apiKey: "AIzaSyAj3HhGzUEID_mvlgwkbwn-sDUzsm_sIhY",
  authDomain: "gen-lang-client-0227104370.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-dream71ptenupdat-b46a78c6-f62f-461e-8588-39985b15745c",
  storageBucket: "gen-lang-client-0227104370.firebasestorage.app",
  messagingSenderId: "607667886478",
  oAuthClientId: "607667886478-r61vr9hb7lm0q5jthamppkn4lsrurtqf.apps.googleusercontent.com"
};

// If loaded via CDN/script tag:
if (typeof window !== 'undefined') {
  window.PTENIT_FIREBASE_CONFIG = firebaseConfig;
}

export default firebaseConfig;
